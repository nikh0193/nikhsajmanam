from django.shortcuts import render
from django.http.response import HttpResponse


from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.core.mail import send_mail
from django.core.mail import EmailMultiAlternatives
from django.template.loader import get_template
from django.template import Context
from django.views.decorators.csrf import csrf_exempt 
from .models import UserCreate

def index(request):
    return render(request, 'index.html', {'title':'index'})


def login(request):
    
    error_message = ''
    if request.method == 'POST':
        
        username = request.POST['email']
        password = request.POST['password']
        
        user = UserCreate.objects.filter(email=username, password=password)
        if len(user)==1:
            request.session['email'] = username
            request.session['name'] = user[0].name
            return redirect(home)
        else:
            error_message = 'Invalid Credentials'
    elif request.method == 'GET':
        action = request.GET.get('action','')
        if action == 'logout':
            request.session.clear()
    return render(request, 'login.html', {'title':'log in', 'error_message':error_message})

def home(request):
    if request.session.get('name'):
        user = UserCreate.objects.all()
        if request.method == 'POST':
            delete_id = request.POST.get('selected_id')
            create = request.POST.get('CREATE')
            if delete_id:
                UserCreate.objects.filter(id=delete_id).delete()
            elif create:
                return redirect(create_user)
                
       

        return render(request, 'home.html', {'title':'Home','name':request.session.get('name'),'query_results':user})
    else:
        return redirect(login)
    
def create_user(request):
    if request.session.get('name'):
        if request.method == 'POST':
            name = request.POST.get('name')
            email = request.POST.get('email')
            password = request.POST.get('password')
            user = UserCreate(name=name, email=email, password=password)
            user.save()
            return redirect(home)
        
        return render(request, 'create.html', {'title':'New User','name':request.session.get('name')})
    else:
        return redirect(login)
        

def update_user(request):
    if request.session.get('name'):
        if request.method == 'POST':
            name = request.POST.get('name')
            email = request.POST.get('email')
            password = request.POST.get('password')
            user = UserCreate(name=name, email=email, password=password)
            user.save()
            return redirect(home)
        else:
            id = request.GET.get('id','')
            user = UserCreate.objects.filter(id=id)
            if user:
                user_details = {'name': user[0].name, 'email': user[0].email}
            return render(request, 'update.html', {'title':'Update User','name':request.session.get('name'),'user_details':user_details})
    else:
        return redirect(login)




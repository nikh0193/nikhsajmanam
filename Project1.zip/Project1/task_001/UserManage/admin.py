from django.contrib import admin
from .models import UserCreate
admin.site.register(UserCreate)
# Register your models here.
